import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';

const socket = io('https://TON_BACKEND_URL'); // Remplace par l'URL de ton backend

function App() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    socket.on('receive_message', (msg) => {
      setMessages((prev) => [...prev, msg]);
    });
  }, []);

  const sendMessage = () => {
    if (message.trim()) {
      socket.emit('send_message', message);
      setMessage('');
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Messagerie entre amis</h1>
      <div>
        {messages.map((msg, i) => (
          <p key={i}>{msg}</p>
        ))}
      </div>
      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Tape ton message ici"
      />
      <button onClick={sendMessage}>Envoyer</button>
    </div>
  );
}

export default App;